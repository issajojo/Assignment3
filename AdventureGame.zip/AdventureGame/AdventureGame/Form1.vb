﻿Public Class Form1
    Dim HP As Integer = 100
    Dim enemy1HP As Integer = 25
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btn1.Text = "Bob"
        btn2.Text = "Sam"
        btn3.Text = "Dan"
        lblStory.Text = "The year is 501,
The world you live in is full of adventures and stories to be told. In this world,
people go through dungeons and plains in search of treasure and fame. There exist
many creatures like skeletons, undead, ghosts, ghouls and goblins. It is said that
even mythical beings like dragons and unicorns are alive. Although right now, there
are ongoing conflicts within the kingdom and its people. The current Monarch’s 
decisions to increase taxes and enforcement of harsher punishments on criminals eventually
lead to mistreatment of people have caused an uproar in the citizen’s of the domain and resulted
in the sights of more bandits and criminals harassing people. This is one of the stories that revolves
around a village on the outskirts of the Tayva Kingdom’s domain, named Suppmore Settlement. 

It begins by you [adventurer], trying to recover the money that was meant to be sent to the kingdom
by their guards that do rounds to each village but was nabbed by a group of bandits who came in the night
and outnumbered you as you were preparing the money. They laughed maniacally and snickered  as you
surrendered the money, knowing that this battle could not be won by yourself. Even in the pitch black 
of night, you saw the way that the bandits had run off towards figuring it would lead to their hideout. 
Now please tell us your name.
"
        lblHP.Text = HP
        lblItems.Text = "Spare medpack, Gun"
    End Sub


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblStory.Click

    End Sub

    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        If btn1.Text = "Bob" Then
            lblStory.Text = "Greetings, " & btn1.Text
            stage2()
        ElseIf btn1.Text = "Help the man up" Then
            lblItems.Text = "Gun"
            lblStory.Text = "The man is actually a bandit in disguise and 
stabs you in the back as you heal him."
            HP = HP - 40
            lblHP.Text = HP
            stage2b()
        ElseIf btn1.Text = "Attack" Then
            enemy1HP = enemy1HP - 20
            If enemy1HP < 1 Then
                stage3()
                lblStory.Text += "You won."
            ElseIf HP < 1 Then
                stage3()
                lblStory.Text += "You lost."
                restart()
            Else
                HP = HP - 20
                lblHP.Text = HP
                lblStory.Text = "You dealt 20 damage to the bandit and he 
did 20 damage to you"
                If HP < 1 Then
                    stage3()
                    lblStory.Text += "You lost."
                    restart()
                End If
            End If
        End If

    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        If btn1.Text = "Bob" Then
            lblStory.Text = "Greetings, " & btn2.Text
            stage2()
        ElseIf btn1.Text = "Help the man up" Then
            lblStory.Text = "The man is actually a bandit in disguise but is 
unable to attack you as you mercy kill him."
            HP = HP
            lblHP.Text = HP
            stage3()
        ElseIf btn1.Text = "Attack" Then
            HP = HP + 20
            lblHP.Text = HP
            If enemy1HP < 1 Then
                stage3()
                lblStory.Text += "You won."
            ElseIf HP < 1 Then
                stage3()
                lblStory.Text += "You lost."
                restart()
            Else
                HP = HP - 20
                lblHP.Text = HP
                lblStory.Text = "your healing was cancelled out by his damage"
                If HP < 1 Then
                    stage3()
                    lblStory.Text += "You lost."
                    restart()
                End If
            End If
        End If
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        If btn1.Text = "Bob" Then
            lblStory.Text = "Greetings, " & btn3.Text
            stage2()
        ElseIf btn1.Text = "Help the man up" Then
            lblStory.Text = "The man is actually a bandit in disguise and 
stabs you in the back as you walk away."
            HP = HP - 20
            lblHP.Text = HP
            stage2b()
        ElseIf btn1.Text = "Attack" Then
            If enemy1HP < 1 Then
                stage3()
                lblStory.Text += "You won."
            ElseIf HP < 1 Then
                stage3()
                lblStory.Text += "You lost."
                restart()

            Else
                HP = HP - 20
                lblHP.Text = HP
                lblStory.Text = "The bandit did 20 damage to you"
                If HP < 1 Then
                    stage3()
                    lblStory.Text += "You lost."
                    restart()
                End If
            End If
        End If
    End Sub

    Private Sub stage2()
        btn1.Text = "Help the man up"
        btn2.Text = "Finish the man off"
        btn3.Text = "Leave the man to die"
        pbIMG2.Visible = True
        lblStory.Text += "
The next day arrives and you’ve prepared to head off into the direction the bandits fled
to and come across a dirty man with his back against a broken carriage...


The man is riddled with what seems to be bullet wounds at the side of the road.
He is dying and needs medical attention immediately.
You can use a medpack to heal him."
    End Sub

    Private Sub stage2b()
        btn1.Text = "Attack"
        btn2.Text = "Heal"
        btn3.Text = "Stand still"
        lblStory.Text += "

You are in combat!"
    End Sub

    Private Sub stage3()
        btn1.Text = "Travel to Area A"
        btn2.Text = "Travel to Area B"
        btn3.Text = "Travel to Area C"
        lblStory.Text = "The fight has ended... "
    End Sub

    Private Sub restart()
        btn1.Text = "Bob"
        btn2.Text = "Sam"
        btn3.Text = "Dan"
        lblStory.Text = "The year is 501,
The world you live in is full of adventures and stories to be told. In this world,
people go through dungeons and plains in search of treasure and fame. There exist
many creatures like skeletons, undead, ghosts, ghouls and goblins. It is said that
even mythical beings like dragons and unicorns are alive. Although right now, there
are ongoing conflicts within the kingdom and its people. The current Monarch’s 
decisions to increase taxes and enforcement of harsher punishments on criminals eventually
lead to mistreatment of people have caused an uproar in the citizen’s of the domain and resulted
in the sights of more bandits and criminals harassing people. This is one of the stories that revolves
around a village on the outskirts of the Tayva Kingdom’s domain, named Suppmore Settlement. 

It begins by you [adventurer], trying to recover the money that was meant to be sent to the kingdom
by their guards that do rounds to each village but was nabbed by a group of bandits who came in the night
and outnumbered you as you were preparing the money. They laughed maniacally and snickered  as you
surrendered the money, knowing that this battle could not be won by yourself. Even in the pitch black 
of night, you saw the way that the bandits had run off towards figuring it would lead to their hideout. 
Now please tell us your name."
        HP = 100
        enemy1HP = 25
        lblHP.Text = HP
        pbIMG2.Visible = False
    End Sub

    Private Sub lblDMG_Click(sender As Object, e As EventArgs) Handles lblItems.Click

    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class

﻿Public Class Form1
    Dim HP As Integer = 100
    Dim enemy1HP As Integer = 25
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btn1.Text = "Bob"
        btn2.Text = "Sam"
        btn3.Text = "Dan"
        lblStory.Text = "(insert story element here), please tell us your name."
        lblHP.Text = HP
        lblItems.Text = "Spare medpack, Gun"
    End Sub


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblStory.Click

    End Sub

    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        If btn1.Text = "Bob" Then
            lblStory.Text = "Greetings, " & btn1.Text
            stage2()
        ElseIf btn1.Text = "Help the man up" Then
            lblItems.Text = "Gun"
            lblStory.Text = "The man is actually a bandit in disguise and 
stabs you in the back as you heal him."
            HP = HP - 40
            lblHP.Text = HP
            stage2b()
        ElseIf btn1.Text = "Attack" Then
            enemy1HP = enemy1HP - 20
            If enemy1HP < 1 Then
                stage3()
                lblStory.Text += "You won."
            ElseIf HP < 1 Then
                stage3()
                lblStory.Text += "You lost."
                restart()
            Else
                HP = HP - 20
                lblHP.Text = HP
                lblStory.Text = "You dealt 20 damage to the bandit and he 
did 20 damage to you"
                If HP < 1 Then
                    stage3()
                    lblStory.Text += "You lost."
                    restart()
                End If
            End If
        End If

    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        If btn1.Text = "Bob" Then
            lblStory.Text = "Greetings, " & btn2.Text
            stage2()
        ElseIf btn1.Text = "Help the man up" Then
            lblStory.Text = "The man is actually a bandit in disguise but is 
unable to attack you as you mercy kill him."
            HP = HP
            lblHP.Text = HP
            stage3()
        ElseIf btn1.Text = "Attack" Then
            HP = HP + 20
            lblHP.Text = HP
            If enemy1HP < 1 Then
                stage3()
                lblStory.Text += "You won."
            ElseIf HP < 1 Then
                stage3()
                lblStory.Text += "You lost."
                restart()
            Else
                HP = HP - 20
                lblHP.Text = HP
                lblStory.Text = "your healing was cancelled out by his damage"
                If HP < 1 Then
                    stage3()
                    lblStory.Text += "You lost."
                    restart()
                End If
            End If
        End If
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        If btn1.Text = "Bob" Then
            lblStory.Text = "Greetings, " & btn3.Text
            stage2()
        ElseIf btn1.Text = "Help the man up" Then
            lblStory.Text = "The man is actually a bandit in disguise and 
stabs you in the back as you walk away."
            HP = HP - 20
            lblHP.Text = HP
            stage2b()
        ElseIf btn1.Text = "Attack" Then
            If enemy1HP < 1 Then
                stage3()
                lblStory.Text += "You won."
            ElseIf HP < 1 Then
                stage3()
                lblStory.Text += "You lost."
                restart()

            Else
                HP = HP - 20
                lblHP.Text = HP
                lblStory.Text = "The bandit did 20 damage to you"
                If HP < 1 Then
                    stage3()
                    lblStory.Text += "You lost."
                    restart()
                End If
            End If
        End If
    End Sub

    Private Sub stage2()
        btn1.Text = "Help the man up"
        btn2.Text = "Finish the man off"
        btn3.Text = "Leave the man to die"
        lblStory.Text += "

You find a starving man with bullet wounds at the side of the road.
He is dying and needs medical attention immediately.
You can use a medpack to heal him."
    End Sub

    Private Sub stage2b()
        btn1.Text = "Attack"
        btn2.Text = "Heal"
        btn3.Text = "Stand still"
        lblStory.Text += "

You are in combat!"
    End Sub

    Private Sub stage3()
        btn1.Text = "Travel to Area A"
        btn2.Text = "Travel to Area B"
        btn3.Text = "Travel to Area C"
        lblStory.Text = "The fight has ended... "
    End Sub

    Private Sub restart()
        btn1.Text = "Bob"
        btn2.Text = "Sam"
        btn3.Text = "Dan"
        lblStory.Text = "(insert story element here), please tell us your name."
        HP = 100
        enemy1HP = 25
        lblHP.Text = HP
    End Sub

    Private Sub lblDMG_Click(sender As Object, e As EventArgs) Handles lblItems.Click

    End Sub
End Class

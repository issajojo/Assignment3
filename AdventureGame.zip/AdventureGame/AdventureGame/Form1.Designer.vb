﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.pbIMG = New System.Windows.Forms.PictureBox()
        Me.lblStory = New System.Windows.Forms.Label()
        Me.lblHP = New System.Windows.Forms.Label()
        Me.lblItems = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.pbIMG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.Location = New System.Drawing.Point(37, 362)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(230, 65)
        Me.btn1.TabIndex = 3
        Me.btn1.Text = "Button1"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.Location = New System.Drawing.Point(534, 362)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(230, 65)
        Me.btn3.TabIndex = 4
        Me.btn3.Text = "btn3"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.Location = New System.Drawing.Point(285, 362)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(230, 65)
        Me.btn2.TabIndex = 5
        Me.btn2.Text = "Button3"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'pbIMG
        '
        Me.pbIMG.Location = New System.Drawing.Point(173, 50)
        Me.pbIMG.Name = "pbIMG"
        Me.pbIMG.Size = New System.Drawing.Size(438, 166)
        Me.pbIMG.TabIndex = 6
        Me.pbIMG.TabStop = False
        '
        'lblStory
        '
        Me.lblStory.AutoSize = True
        Me.lblStory.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStory.Location = New System.Drawing.Point(55, 230)
        Me.lblStory.Name = "lblStory"
        Me.lblStory.Size = New System.Drawing.Size(92, 25)
        Me.lblStory.TabIndex = 7
        Me.lblStory.Text = "lblStory"
        '
        'lblHP
        '
        Me.lblHP.AutoSize = True
        Me.lblHP.Location = New System.Drawing.Point(13, 94)
        Me.lblHP.Name = "lblHP"
        Me.lblHP.Size = New System.Drawing.Size(39, 13)
        Me.lblHP.TabIndex = 8
        Me.lblHP.Text = "Label1"
        '
        'lblItems
        '
        Me.lblItems.AutoSize = True
        Me.lblItems.Location = New System.Drawing.Point(638, 94)
        Me.lblItems.Name = "lblItems"
        Me.lblItems.Size = New System.Drawing.Size(39, 13)
        Me.lblItems.TabIndex = 9
        Me.lblItems.Text = "Label1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(-1, 62)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(168, 29)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Health Points"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(636, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 29)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Items"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblItems)
        Me.Controls.Add(Me.lblHP)
        Me.Controls.Add(Me.lblStory)
        Me.Controls.Add(Me.pbIMG)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.pbIMG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn1 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents pbIMG As PictureBox
    Friend WithEvents lblStory As Label
    Friend WithEvents lblHP As Label
    Friend WithEvents lblItems As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
